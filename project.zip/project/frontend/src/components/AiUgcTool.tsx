import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { Noise } from "noisejs";

/**
 * AiUgcTool
 *
 * A React component that provides a simple interface for generating 3D assets
 * based on user prompts and displaying them within a Three.js scene. It
 * includes procedural terrain generation as a baseline environment and a
 * placeholder function for integrating AI asset creation. This file is
 * intended as a starting point—you will need to connect it to a backend
 * service to perform actual prompt‑to‑asset generation (e.g., via an API).
 */
const AiUgcTool: React.FC = () => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [prompt, setPrompt] = useState("");
  const [assets, setAssets] = useState<THREE.Mesh[]>([]);
  const sceneRef = useRef<THREE.Scene | null>(null);

  // Initialize Three.js scene on mount
  useEffect(() => {
    if (!mountRef.current) return;
    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x99ccee);
    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 10, 20);
    sceneRef.current = scene;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    mountRef.current.appendChild(renderer.domElement);

    // Basic lighting
    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 0.8);
    hemiLight.position.set(0, 20, 0);
    scene.add(hemiLight);
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(10, 10, 10);
    scene.add(dirLight);

    // Add procedural terrain
    const terrain = generateTerrain();
    scene.add(terrain);

    // Render loop
    const animate = () => {
      requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      // Cleanup on unmount
      renderer.dispose();
      scene.clear();
    };
  }, []);

  /**
   * generateTerrain
   *
   * Generates a simple heightmap using Perlin noise to create a plane mesh
   * representing terrain. Adjust parameters for different results.
   */
  const generateTerrain = (): THREE.Mesh => {
    const size = 100;
    const segments = 64;
    const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
    const noise = new Noise(Math.random());

    const positions = (geometry.attributes.position as THREE.BufferAttribute);
    for (let i = 0; i < positions.count; i++) {
      const x = positions.getX(i) / size;
      const y = positions.getY(i) / size;
      const elevation = noise.perlin2(x * 4, y * 4);
      positions.setZ(i, elevation * 2);
    }
    geometry.computeVertexNormals();
    const material = new THREE.MeshStandardMaterial({ color: 0x88cc88, flatShading: false });
    const mesh = new THREE.Mesh(geometry, material);
    mesh.rotation.x = -Math.PI / 2;
    return mesh;
  };

  /**
   * handleGenerate
   *
   * Placeholder for AI asset generation. Replace this function with a call
   * to your backend API to generate assets from text prompts. For now it
   * simply creates a box with a random color and adds it to the scene.
   */
  const handleGenerate = async () => {
    if (!sceneRef.current) return;
    if (!prompt) return;
    // TODO: call backend AI service with `prompt`
    // Example stub: create a colored box
    const size = Math.random() * 2 + 0.5;
    const geometry = new THREE.BoxGeometry(size, size, size);
    const color = new THREE.Color(Math.random(), Math.random(), Math.random());
    const material = new THREE.MeshStandardMaterial({ color });
    const box = new THREE.Mesh(geometry, material);
    box.position.set((Math.random() - 0.5) * 20, size / 2, (Math.random() - 0.5) * 20);
    sceneRef.current.add(box);
    setAssets([...assets, box]);
  };

  return (
    <div style={{ width: "100%", height: "100%" }}>
      <div style={{ display: "flex", marginBottom: "0.5rem" }}>
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the asset to generate…"
          style={{ flex: 1, padding: "0.5rem" }}
        />
        <button
          onClick={handleGenerate}
          style={{ padding: "0.5rem 1rem", marginLeft: "0.5rem" }}
        >
          Generate
        </button>
      </div>
      <div
        ref={mountRef}
        style={{ width: "100%", height: "600px", border: "1px solid #ccc" }}
      ></div>
    </div>
  );
};

export default AiUgcTool;